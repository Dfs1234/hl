export class nutrients {
    fat: number;
    sugar: number;
    protein: number;
    fiber: number;
    sodium: number;
    cholesterol: number;
    carbs: number;
}