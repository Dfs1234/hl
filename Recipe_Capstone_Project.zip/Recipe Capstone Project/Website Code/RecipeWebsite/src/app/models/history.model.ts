export class history {
    recipeName: string;
    author: string;
    username: string;
    recipeId: number;
}
