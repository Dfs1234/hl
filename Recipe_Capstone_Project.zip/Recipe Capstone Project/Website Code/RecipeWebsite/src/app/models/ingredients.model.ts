export class ingredients {
    text: string;
    weight: number;
}