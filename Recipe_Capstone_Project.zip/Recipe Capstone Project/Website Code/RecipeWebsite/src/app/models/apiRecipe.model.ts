import { recipe } from "./recipe.model";

export class APIRecipe {
    APIRecipes: Array<recipe>
    DatabaseRecipes: Array<recipe>
}