export class user {
    username: String;
    password: String;
}