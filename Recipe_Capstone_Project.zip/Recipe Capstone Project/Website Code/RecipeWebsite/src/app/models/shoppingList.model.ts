export class shoppingList {
    shoppingList: Array<string>;
}