export class userRegister {
    user_id: Number;
    username: String;
    password: String;
    email: String;
    age: Number;
    name: String;
}