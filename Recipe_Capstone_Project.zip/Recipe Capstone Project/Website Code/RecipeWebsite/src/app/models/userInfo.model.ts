export class userInfo {
    age: number;
    email: string;
    name: string;
    userName: string;
}
