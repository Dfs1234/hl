FOLDER ORGANIZATION FOR BACKEND FOLDER

Backend\server\src\API contains calls made to the third party API.
Backend\server\src\registration contains the majority of our server calls.
Backend\server\src\security contains password encryption.

FOLDER ORGANIZATION FOR WEBSITE FOLDER

Website\RecipeWebsite\src\app\components contains individual components/views for the website.
Website\RecipeWebsite\src\app\models contains classes for objects.
Website\RecipeWebsite\src\app\services contains the service calls to the server.

FOLDER ORGANIZATION FOR ANDROID FOLDER

Android\Recipe Android Application\app\src\main\java\com\example\kchu0\home contains classes, activities, and fragments.
Android\Recipe Android Application\app\src\main\res\layout contains the XML documents for each activity.